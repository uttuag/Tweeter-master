import React, { useState } from "react";

function CTSearchTag(props){
  
return <>
    <div className="ctSearchBlock">
    <p id="ctSearchHash" >#{props.hashtag}</p>
      
       
    </div>
</>
}

export default CTSearchTag