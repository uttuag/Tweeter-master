// import React from "react";
// import { useEffect } from "react";
// import Spinner from 'react-bootstrap/Spinner';

// function SpinnerLoad (props){
//     useEffect(()=>{
//         if(props.loading){
//             document.style.body.opacity = 0.5;
//         }
//         else{
//             document.style.body.opacity = 1;
//         }
//     })
//     return<>
// {props.loading?<Spinner animation="border" variant="light" 
//     style={{zIndex:"4",
//         position:"fixed",
//         top:"45vh",
//         left:"50vw"}} />:null}
//     </>
// }

// export default SpinnerLoad