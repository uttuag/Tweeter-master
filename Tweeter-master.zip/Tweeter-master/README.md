TWEETER : a socio website which provides users with the feature to grow their social connections, raise any issue or get updated of what's happening around
          Users can join TWEETER by simply creating their account, having an updated profile, and can create any tweets. Tweeter provides u the feature to have an                 experience of real-time chats with your connections.
          
FEATURES :
1. SignIn/ SignUp or Google Authentication
2. Create, Share, Reply, Retweet, Like or Bookmark any tweet
3. Notifications section to have all new notification
4. Bookmarks section to see your bookmarks
5. Real time chat application using web-sockets.
6. Profile page

TECH-STACKS :
Frontend: HTML, CSS, JS, ReactJS, Redux
Backend: NodeJS, ExpressJS, PostgreSql
Designing: Figma

IMAGES :
![tweeter login](https://user-images.githubusercontent.com/104606182/216806589-f8b0da49-5e79-4acf-89b3-1bd48c2735d4.PNG)
![tweeter 2](https://user-images.githubusercontent.com/104606182/216806632-5243785a-56eb-49eb-a251-c9c2736dfb2f.PNG)
![tweeter 1](https://user-images.githubusercontent.com/104606182/216806660-7ce5e45a-0780-43b0-b7d6-d186693b0746.PNG)
![tweeter 5](https://user-images.githubusercontent.com/104606182/216806661-0cd4e4a9-2f8f-4d31-b77a-aa4dfe0cf72b.PNG)
![tweeter 6](https://user-images.githubusercontent.com/104606182/216806663-9ad60ccc-46a2-446d-adf3-b1cb47e91fdc.PNG)
![tweeter 7](https://user-images.githubusercontent.com/104606182/216806664-0a591521-af34-471c-b954-791b8fd5228f.PNG)
![tweeter 8](https://user-images.githubusercontent.com/104606182/216806666-0f982288-6447-4628-9f29-ffd29946e9f7.PNG)
![tweeter 9](https://user-images.githubusercontent.com/104606182/216806667-b4b4940d-3fba-45f1-87b3-514fbdd6338a.PNG)

